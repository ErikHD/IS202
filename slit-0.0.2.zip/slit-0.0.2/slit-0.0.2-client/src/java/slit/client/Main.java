/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slit.client;

/*
 * Make sure that you import classes from the javafx library
 * There are classes with the same names as the fx classes
 * in the Swing and Awt libraries, so it is easy to select
 * the wrong class if you use the ctl-i command in netbeans
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;



/**
 *
 * @author evenal
 */
public class Main extends Application
{

    /**
     * Textfields for the operands (the numbers that are input),
     * and the result of the operation *
     */
    private TextField n1;
    private TextField n2;
    private TextField result;

    /**
     * The FX system will call start(), to start the application.
     *
     * @param stage the top level window
     * @throws Exception if anything goes wrong.
     */
    @Override
    public void start(Stage stage) throws Exception {
        assert stage != null;

        Scene scene = createScene();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Build the scene graph. This is done in a separate
     * methods to get better cohesion.
     *
     * @return the newly constructed scenegraph
     */
    private Scene createScene() {
        // create input fields
        GridPane grid = new GridPane();
        Text l1 = new Text("Et tall");
        Text l2 = new Text("Et tall til");
        n1 = new TextField();
        n2 = new TextField();

        // and buttons
        Button plus = new Button("+");
        plus.setOnAction(new OperatorHandler(Operator.ADD));
        Button minus = new Button("-");
        minus.setOnAction(new OperatorHandler(Operator.SUB));
        Button mult = new Button("*");
        mult.setOnAction(new OperatorHandler(Operator.MUL));
        Button div = new Button("/");
        div.setOnAction(new OperatorHandler(Operator.DIV));

        HBox buttons = new HBox();
        buttons.getChildren().add(plus);
        buttons.getChildren().add(minus);
        buttons.getChildren().add(mult);
        buttons.getChildren().add(div);

        result = new TextField();
        // and add everything to the grid
        grid.add(l1, 0, 0);
        grid.add(n1, 1, 0);
        grid.add(l2, 0, 1);
        grid.add(n2, 1, 1);
        grid.add(buttons, 0, 2, 2, 1);
        grid.add(result, 0, 3, 2, 1);
        grid.setHgap(3);
        grid.setVgap(3);

        // return the scene graph
        Scene s = new Scene(grid);
        return s;
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch();
    }



    private class OperatorHandler implements EventHandler<ActionEvent>
    {

        Operator op;

        public OperatorHandler(Operator op) {
            this.op = op;
        }


        @Override
        public void handle(ActionEvent event) {
            double x = getNumber(n1);
            double y = getNumber(n2);
            result.setText(Double.toString(computeResult(op, x, y)));
        }

        double getNumber(TextField input) {
            double value = Double.valueOf(input.getText());
            return value;
        }

        double computeResult(Operator op, double x, double y) {
            switch (op) {
            case ADD:
                return x + y;
            case SUB:
                return x - y;
            case MUL:
                return x * y;
            case DIV:
                return x / y;
            }
            return Double.NaN;
        }
    }



    private static enum Operator
    {
        ADD, SUB, MUL, DIV;
    }

}
